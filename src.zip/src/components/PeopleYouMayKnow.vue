<template>
<div class="p-4 bg-white border border-gray-200 rounded-lg">
        <h3 class="mb-6 text-xl">People you may know</h3>

        <div class="space-y-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeyoNipuLHTsJiGMY3J8JXdSRlEulM_g7xwMi7O94aNSUv3F8CcIJvJQeeTgmbqG0aB2M&usqp=CAU" class="w-[40px] rounded-full">
                    
                    <p class="text-xs"><strong>Yuyao</strong></p>
                </div>

                <a href="#" class="py-2 px-3 bg-purple-600 text-white text-xs rounded-lg">Show</a>
            </div>

            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeyoNipuLHTsJiGMY3J8JXdSRlEulM_g7xwMi7O94aNSUv3F8CcIJvJQeeTgmbqG0aB2M&usqp=CAU" class="w-[40px] rounded-full">
                    
                    <p class="text-xs"><strong>Yuyao</strong></p>
                </div>

                <a href="#" class="py-2 px-3 bg-purple-600 text-white text-xs rounded-lg">Show</a>
            </div>

            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeyoNipuLHTsJiGMY3J8JXdSRlEulM_g7xwMi7O94aNSUv3F8CcIJvJQeeTgmbqG0aB2M&usqp=CAU" class="w-[40px] rounded-full">
                    
                    <p class="text-xs"><strong>Yuyao</strong></p>
                </div>

                <a href="#" class="py-2 px-3 bg-purple-600 text-white text-xs rounded-lg">Show</a>
            </div>
        </div>
    </div>
</template>